//
// Created by aichao on 2025/2/8.
//

#pragma once

#ifdef _WIN32
#define strdup _strdup
#endif