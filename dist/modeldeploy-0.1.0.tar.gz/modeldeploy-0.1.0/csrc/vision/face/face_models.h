//
// Created by aichao on 2025/4/7.
//

#pragma once

#include "csrc/vision/face/face_det/scrfd.h"
#include "csrc/vision/face/face_age/seetaface_age.h"
#include "csrc/vision/face/face_as/face_as_first.h"
#include "csrc/vision/face/face_as/face_as_second.h"
#include "csrc/vision/face/face_as/face_as_pipeline.h"
#include "csrc/vision/face/face_gender/seetaface_gender.h"
#include "csrc/vision/face/face_rec/seetaface.h"
#include "csrc/vision/face/face_rec_pipeline/face_rec_pipeline.h"
