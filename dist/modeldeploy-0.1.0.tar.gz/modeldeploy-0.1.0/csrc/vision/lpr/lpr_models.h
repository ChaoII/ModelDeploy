//
// Created by aichao on 2025/4/7.
//

#pragma once

#include "csrc/vision/lpr/lpr_det/lpr_det.h"
#include "csrc/vision/lpr/lpr_rec/lpr_rec.h"
#include "csrc/vision/lpr/lpr_pipeline/lpr_pipeline.h"