//
// Created by aichao on 2025/5/22.
//

#pragma once

namespace modeldeploy {
    enum Backend {
        ORT,
        NONE
    };

    enum Device {
        CPU,
        GPU
    };
}
